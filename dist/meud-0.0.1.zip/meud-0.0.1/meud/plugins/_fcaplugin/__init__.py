"""Plugin for fca"""
from scalingdialog import GetScaledContext
from filteringdialog import GetFilteredConcepts