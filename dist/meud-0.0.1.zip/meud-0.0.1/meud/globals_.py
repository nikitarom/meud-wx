#!/usr/bin/env python
# encoding: utf-8
DEBUG = True

files_categories = {
"mvcontexts" : "Many-valued contexts",
"scales" : "Scales",
"contexts" : "Contexts",
"concept_systems" : "Concept Systems"
}

workspace_path = r"workspace"
plugins_path = r"meud/plugins"

