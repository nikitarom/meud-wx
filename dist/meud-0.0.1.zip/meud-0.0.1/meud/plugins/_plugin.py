class Plugin(object):
    name = "undefined"
    
    def get_actions(self, item):
        pass
    
    def do_action(self, item, workspace, action):
        pass