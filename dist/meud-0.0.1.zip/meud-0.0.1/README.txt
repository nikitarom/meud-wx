meud

-------------------------------------------------------------------------------

Some images included in this software is the part of the following projects:
	
--- Tango Destop Project

	<http://tango.freedesktop.org/>

--- Fugue Icons

	Copyright (C) 2010 Yusuke Kamiyamane. All rights reserved.
	The icons are licensed under a Creative Commons Attribution
	3.0 license. <http://creativecommons.org/licenses/by/3.0/>
	<http://p.yusukekamiyamane.com/>